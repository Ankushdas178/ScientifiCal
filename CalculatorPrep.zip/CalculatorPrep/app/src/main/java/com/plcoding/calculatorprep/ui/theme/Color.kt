package com.plcoding.calculatorprep.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)

val MediumGray = Color(0xFF2E2E2E)
val LightGray = Color(0xFF4652A3)
val Orange = Color(0xFF388CA5)
val blue = Color(0xFF441C7E)